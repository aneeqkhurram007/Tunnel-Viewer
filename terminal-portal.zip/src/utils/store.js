const state = {
    users: [],
    loggedIn: false
}
export default state